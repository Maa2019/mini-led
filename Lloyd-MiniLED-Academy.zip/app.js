/* =====================================================================
   LLOYD MINI-LED ACADEMY  ·  v3
   A structured learning path, not a document.
   lesson -> see it -> retrieve it -> apply it -> review what you missed
   ===================================================================== */
const $ = id => document.getElementById(id);
const esc = t => String(t).replace(/&(?!amp;|lt;|gt;|#)/g,"&amp;").replace(/</g,"&lt;");
const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
function rippleAt(el, ev){
  try{
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const r = el.getBoundingClientRect(), d = Math.max(r.width, r.height);
    const s = document.createElement("span");
    s.className = "rip"; s.style.width = s.style.height = d + "px";
    s.style.left = ((ev&&ev.clientX?ev.clientX:r.left+r.width/2) - r.left - d/2) + "px";
    s.style.top  = ((ev&&ev.clientY?ev.clientY:r.top+r.height/2) - r.top - d/2) + "px";
    el.appendChild(s); setTimeout(()=>s.remove(), 600);
  }catch(e){}
}
function buzz(p){ try{ if(navigator.vibrate) navigator.vibrate(p); }catch(e){} }

/* ---------- progress store ---------- */
const KEY = "lloyd_miniled_v3";
let P = { done:{}, best:{}, xp:0, wrong:[], streak:0, last:"", certified:false, speedBest:0 };
try{ const r = localStorage.getItem(KEY); if(r) P = Object.assign(P, JSON.parse(r)); }catch(e){}
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(P)); }catch(e){} }
function touchStreak(){
  const t = new Date().toISOString().slice(0,10);
  if (P.last === t) return;
  const y = new Date(Date.now()-864e5).toISOString().slice(0,10);
  P.streak = (P.last === y) ? P.streak + 1 : 1;
  P.last = t; save();
}
function addXP(n){ P.xp += n; save(); }
function markWrong(i){ if (P.wrong.indexOf(i) < 0){ P.wrong.push(i); save(); } }
function clearWrong(i){ const k = P.wrong.indexOf(i); if(k>-1){ P.wrong.splice(k,1); save(); } }
function shuffle(a){ a=a.slice(); for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]];} return a; }
/* =====================================================================
   TV RENDERER — a screen whose backlight is really simulated
   ===================================================================== */
function tvShell(inner, opts){
  opts = opts || {};
  return '<div class="tvwrap"><div class="tv' + (opts.mini ? ' mtv' : '') + '">' +
    '<div class="bezel"><div class="scr" id="' + (opts.id || '') + '">' +
      inner + '<div class="vig"></div><div class="shine"></div>' +
    '</div></div><div class="neck"></div><div class="base"></div>' +
    (opts.mini ? '' : '<div class="brandbar">L L O Y D</div>') +
  '</div>' + (opts.cap ? '<div class="caption">' + opts.cap + '</div>' : '') + '</div>';
}

/* Build a backlight zone grid.
   cols x rows zones. scene(x,y) returns 0..1 brightness for that zone. */
function zoneGrid(cols, rows, scene, tint){
  let cells = "";
  for (let y = 0; y < rows; y++){
    for (let x = 0; x < cols; x++){
      const v = Math.max(0, Math.min(1, scene(x/(cols-1||1), y/(rows-1||1))));
      const c = tint ? tint(v) : ('rgba(' + [255,255,255].join(',') + ',' + v + ')');
      const glow = v > .35 ? 'box-shadow:0 0 ' + (10*v).toFixed(1) + 'px rgba(160,205,255,' + (v*.5).toFixed(2) + ')' : '';
      cells += '<div class="z" style="background:' + c + ';' + glow + '"></div>';
    }
  }
  return '<div class="zones" style="grid-template-columns:repeat(' + cols +
         ',1fr);grid-template-rows:repeat(' + rows + ',1fr)">' + cells + '</div>';
}

/* night scene: a bright moon top-right + a few stars, rest near black */
function nightScene(x, y){
  const dx = x - .74, dy = y - .26;
  const moon = Math.exp(-((dx*dx)/0.006 + (dy*dy)/0.012));
  const stars = Math.exp(-((x-.18)**2/0.002 + (y-.62)**2/0.004)) * .55
              + Math.exp(-((x-.42)**2/0.0016 + (y-.18)**2/0.003)) * .42
              + Math.exp(-((x-.60)**2/0.0014 + (y-.76)**2/0.003)) * .38;
  return Math.min(1, moon + stars + .012);
}

/* =====================================================================
   LIVE DEMO MODULES — one animated screen per technology
   ===================================================================== */
let dIdx = 0, dState = {};

function ds(k, def){ return dState[k] === undefined ? def : dState[k]; }

/* ---- 1. LOCAL DIMMING ---- */
function dDim(){
  const mini = ds("dim", true);
  const cfg = mini ? [24,13] : [4,2];
  return {
    scr: zoneGrid(cfg[0], cfg[1], nightScene,
      v=>'rgba(' + Math.round(200+55*v) + ',' + Math.round(215+40*v) + ',255,' +
         (0.04+0.96*v).toFixed(3) + ')') +
      '<div class="ovl">' + (mini ? "MINI LED · 312 ZONES" : "NORMAL LED · 8 ZONES") + '</div>',
    cap:"Watch the black sky around the moon",
    seg:[["dim",false,"Normal LED"],["dim",true,"Mini LED"]],
    tp:[["Few big zones wash a whole block grey. That grey is called blooming.","#EF2B36"],
        ["Thousands of tiny zones switch off exactly where the picture is dark.","#31B85C"],
        ["This is full array local dimming — light controlled area by area.","#3BB8F0"]]
  };
}

/* ---- 2. BRIGHTNESS IN A BRIGHT ROOM ---- */
function dBright(){
  const n = ds("nits", 1400), sun = ds("sun", true);
  const f = n/1400;
  return {
    scr: zoneGrid(20,11,(x,y)=>{
        const s = Math.exp(-((x-.72)**2/0.012 + (y-.24)**2/0.02));
        const m = Math.exp(-((x-.36)**2/0.09 + (y-.60)**2/0.06))*.45;
        return Math.min(1, s*f + m*(0.35+0.65*f) + .02);
      }, v=>'rgba(255,244,214,' + (0.03+0.97*v).toFixed(3) + ')') +
      '<div class="sun' + (sun ? ' on' : '') + '"></div>' +
      '<div class="ovl">' + (sun ? "BRIGHT ROOM" : "DARK ROOM") + '</div>' +
      '<div class="nits">' + n + ' nits</div>',
    cap:"Drag the slider. Then switch the room lights on.",
    range:{key:"nits", min:300, max:1400, step:50, label:" nits"},
    seg:[["sun",false,"Dark room"],["sun",true,"Bright room"]],
    tp:[["A 300 nit TV looks fine in a dark showroom and washes out at home.","#EF2B36"],
        ["1400 nits holds the picture with the curtains open.","#F5B617"],
        ["Ask the customer: TV kis room mein lagega — hall ya bedroom?","#3BB8F0"]]
  };
}

/* ---- 3. SDR vs DOLBY VISION — real colour difference ---- */
const SDR_SW = ["#7E5F4B","#6B7A63","#5E6E86","#8A6B72","#7A7458","#5F6B6E"];
const DV_SW  = ["#FF6A1F","#22C55E","#1E7FD0","#EC1F5E","#F5B617","#12B8A6"];
function dColour(){
  const dv = ds("dv", true);
  const set = dv ? DV_SW : SDR_SW;
  let sw = "";
  set.forEach(c => sw += '<div style="background:' + c +
    (dv ? ';box-shadow:0 0 14px ' + c + '66' : '') + '"></div>');
  const base = dv
    ? 'linear-gradient(125deg,#06122B,#0E3A6B 34%,#1E7FD0 58%,#F5B617 84%,#EF4A1F)'
    : 'linear-gradient(125deg,#1A2233,#2C3A4E 34%,#47566B 58%,#8A8368 84%,#8A6656)';
  return {
    scr: '<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:' + base + '"></div></div>' +
      '<div class="sw">' + sw + '</div>' +
      '<div class="ovl">' + (dv ? "DOLBY VISION" : "SDR") + '</div>' +
      '<div class="swlab">' + (dv ? "RICH · DEEP · CLOSE TO REAL" : "FLAT · MUTED · WASHED") + '</div>',
    cap:"Same scene, same swatches. Only the format changes.",
    seg:[["dv",false,"SDR"],["dv",true,"Dolby Vision"]],
    tp:[["SDR compresses the bright and dark ends — colour goes flat.","#94A2CE"],
        ["Dolby Vision carries scene-by-scene data for deeper contrast and richer colour.","#F5B617"],
        ["On the floor: play the SAME title on both sets. Never describe this — show it.","#3BB8F0"]]
  };
}

/* ---- 4. DCI-P3 94% COLOUR GAMUT ---- */
function dGamut(){
  const wide = ds("gam", true);
  const poly = wide ? "50,8 92,78 8,78" : "50,30 74,70 26,70";
  const fill = wide ? "url(#gw)" : "#4A5578";
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:#050A1C"></div></div>' +
      '<div class="gam"><svg viewBox="0 0 100 88" preserveAspectRatio="xMidYMid meet">' +
      '<defs><linearGradient id="gw" x1="0" y1="1" x2="1" y2="0">' +
      '<stop offset="0" stop-color="#1E7FD0"/><stop offset=".45" stop-color="#31B85C"/>' +
      '<stop offset=".75" stop-color="#F5B617"/><stop offset="1" stop-color="#EF2B36"/>' +
      '</linearGradient></defs>' +
      '<polygon points="50,8 92,78 8,78" fill="none" stroke="#2C3768" stroke-width="1.2"/>' +
      '<polygon class="gpoly" points="' + poly + '" fill="' + fill + '" opacity="' +
      (wide ? ".92" : ".7") + '"/></svg></div>' +
      '<div class="ovl">' + (wide ? "DCI-P3 94%" : "STANDARD GAMUT") + '</div>' +
      '<div class="swlab">' + (wide ? "WIDE COLOUR RANGE" : "NARROW COLOUR RANGE") + '</div>',
    cap:"The triangle is how much colour the panel can actually show",
    seg:[["gam",false,"Standard"],["gam",true,"DCI-P3 94%"]],
    tp:[["Gamut is the RANGE of colour. Accuracy is whether it is the CORRECT colour.","#94A2CE"],
        ["Mini-LED gives DCI-P3 94% range with 100% colour accuracy — both, not one.","#8B5CF6"],
        ["DCI-P3 is the standard cinema is graded in. Wider gamut = closer to what the director saw.","#3BB8F0"]]
  };
}

/* ---- 5. 1.07 BILLION COLOURS ---- */
function dColours(){
  const qd = ds("qd", true);
  const n = qd ? "1.07 BILLION" : "16.7 MILLION";
  const base = qd
    ? 'conic-gradient(from 200deg,#EF2B36,#F5B617,#31B85C,#12B8A6,#1E7FD0,#8B5CF6,#EF2B36)'
    : 'conic-gradient(from 200deg,#6E5560,#7A7258,#5F7061,#4F6A6C,#4A5F80,#5D5279,#6E5560)';
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:' + base + ';filter:blur(9px) saturate(' +
      (qd ? 1.25 : .75) + ')"></div></div>' +
      '<div class="cnt">' + n + '</div><div class="cntsub">COLOURS ON SCREEN</div>' +
      '<div class="ovl">' + (qd ? "QD DISPLAY · 10-BIT" : "STANDARD · 8-BIT") + '</div>',
    cap:"More shades means smoother skies and skin, with no banding",
    seg:[["qd",false,"Standard panel"],["qd",true,"QD Display"]],
    tp:[["8-bit gives 16.7 million shades. Skies show visible steps, called banding.","#94A2CE"],
        ["The quantum dot layer takes it to 1.07 billion shades — gradients stay smooth.","#F5B617"],
        ["Demo it on a sunset or a dark sky. Banding is where cheap panels give themselves away.","#3BB8F0"]]
  };
}

/* ---- 6. MEMC MOTION ---- */
function dMemc(){
  const on = ds("memc", true);
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:linear-gradient(160deg,#0C1B3A,#123055)"></div></div>' +
      (on ? '' : '<div class="trail"></div>') +
      '<div class="ball' + (on ? '' : ' blur') + '"></div>' +
      '<div class="ovl">' + (on ? "MEMC ON · SHARP" : "MEMC OFF · BLUR") + '</div>',
    cap:"Watch the ball as it crosses",
    seg:[["memc",false,"MEMC Off"],["memc",true,"MEMC On"]],
    tp:[["MEMC inserts frames between frames so fast motion stops smearing.","#31B85C"],
        ["120Hz keeps the whole picture fluid, not just the moving object.","#F5B617"],
        ["Demo on cricket or racing. Point at the ball, not at the spec sheet.","#3BB8F0"]]
  };
}

/* ---- 7. ALLM / GAMING LATENCY ---- */
function dAllm(){
  const on = ds("allm", true);
  const ms = on ? 12 : 88, pct = on ? 14 : 88;
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:linear-gradient(160deg,#10163A,#241A44)"></div></div>' +
      '<div class="chlab">' + (on ? "GAME MODE · ALLM ON" : "STANDARD MODE") + '</div>' +
      '<div class="lat"><div class="latbar"><i style="width:' + pct + '%;background:' +
      (on ? "#31B85C" : "#EF2B36") + '"></i></div>' +
      '<div class="latlab"><span>Input lag</span><span>' + ms + ' ms</span></div></div>' +
      '<div class="ovl">' + (on ? "LOW LATENCY" : "HIGH LATENCY") + '</div>',
    cap:"Input lag is the delay between the controller and the screen",
    seg:[["allm",false,"Standard"],["allm",true,"ALLM On"]],
    tp:[["ALLM switches the TV to game mode automatically when a console connects.","#31B85C"],
        ["No menu diving. The customer never has to find the setting.","#F5B617"],
        ["Ask if anyone at home games. If yes, ALLM plus 120Hz closes the sale.","#3BB8F0"]],
    note:"Latency figures shown are illustrative, to explain the concept."
  };
}

/* ---- 8. DOLBY AUDIO · 60W 2.1 WITH WOOFER ---- */
function dAudio(){
  const big = ds("aud", true);
  let atms = "";
  if (big) for (let i=0;i<3;i++)
    atms += '<div class="atm go" style="left:22%;top:' + (26+i*13) + '%;animation-delay:' +
            (i*1.1) + 's"></div>';
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:linear-gradient(160deg,#0A1230,#1D1440)"></div></div>' +
      '<div class="chlab">' + (big ? "2.1 CHANNEL · 60W · WOOFER" : "2.0 CHANNEL · 20W") + '</div>' +
      atms +
      '<div class="ring go" style="animation-delay:0s"></div>' +
      (big ? '<div class="ring go" style="animation-delay:.65s"></div>' +
             '<div class="ring go" style="animation-delay:1.3s"></div>' : '') +
      '<div class="spk">' +
        '<div class="cone pump' + (big ? '' : ' slow') + '"></div>' +
        (big ? '<div class="cone big pump"></div>' : '') +
        '<div class="cone pump' + (big ? '' : ' slow') + '"></div>' +
      '</div>' +
      '<div class="ovl">' + (big ? "DOLBY AUDIO" : "BASIC AUDIO") + '</div>',
    cap:"The big centre cone is the inbuilt woofer",
    seg:[["aud",false,"2.0 · 20W"],["aud",true,"2.1 · 60W"]],
    tp:[["2.1 means left, right AND a dedicated woofer for bass — inside the TV.","#F5B617"],
        ["60W fills a hall. Most LED sets ship 20W and need a soundbar.","#31B85C"],
        ["Dolby Audio spatial sound places effects around the room, not just left and right.","#8B5CF6"],
        ["Demo with a bass-heavy scene at MATCHED loudness, not matched volume number.","#3BB8F0"]]
  };
}

/* ---- 9. AIRPLAY / APPLE ECOSYSTEM ---- */
function dAir(){
  const on = ds("air", true);
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:' + (on
        ? 'linear-gradient(150deg,#08122E,#123A6B 55%,#1E7FD0)'
        : 'linear-gradient(150deg,#0C1024,#1A2140)') + '"></div></div>' +
      '<div class="chlab">' + (on ? "AIRPLAY CONNECTED" : "NO CASTING") + '</div>' +
      '<div class="phone"><i></i><b></b></div>' +
      (on ? '<div class="fly go"></div>' +
            '<div class="apwave go"></div>' +
            '<div class="apwave go" style="animation-delay:.6s"></div>' +
            '<div class="apwave go" style="animation-delay:1.2s"></div>' : '') +
      '<div class="ovl">' + (on ? "APPLE ECOSYSTEM" : "PHONE ONLY") + '</div>',
    cap:"His own phone content, on the big screen, in seconds",
    seg:[["air",false,"Off"],["air",true,"AirPlay On"]],
    tp:[["AirPlay puts his own photos and video on the TV without any cable or app.","#3BB8F0"],
        ["Apple TV+, Apple Music and HomeKit all work with the WebOS Mini-LED line.","#8B5CF6"],
        ["If he owns an iPhone, do this FIRST. It converts faster than any spec.","#F5B617"]],
    note:"AirPlay, HomeKit, Apple TV+ and Apple Music are on the WebOS Mini-LED line."
  };
}

/* ---- 10. FAR FIELD VOICE ---- */
function dVoice(){
  const on = ds("voice", true);
  return {
    scr:'<div class="zones" style="grid-template-columns:1fr;grid-template-rows:1fr">' +
      '<div class="z" style="background:linear-gradient(160deg,#0A1330,#10304F)"></div></div>' +
      '<div class="chlab">' + (on ? "FAR FIELD VOICE" : "REMOTE MIC ONLY") + '</div>' +
      '<div class="mic">\u25CF</div>' +
      (on ? '<div class="vw go"></div><div class="vw go" style="animation-delay:.7s"></div>' +
            '<div class="vw go" style="animation-delay:1.4s"></div>' +
            '<div class="vtext go">\u201COK Google, cricket lagao\u201D</div>' : '') +
      '<div class="ovl">' + (on ? "HANDS FREE" : "REMOTE NEEDED") + '</div>',
    cap:"Speak from the sofa. No remote in hand.",
    seg:[["voice",false,"Remote mic"],["voice",true,"Far field"]],
    tp:[["Far field mics pick up the voice from across the room, not just at the remote.","#31B85C"],
        ["Google Assistant understands Hindi and regional speech.","#F5B617"],
        ["Demo it from three metres away. Ask HIM to speak, not you.","#3BB8F0"]],
    note:"Far Field Voice is on the Google TV 5.0 Mini-LED line."
  };
}


const DEMOS = {
  dim:["Local Dimming",dDim], bright:["Brightness",dBright], dv:["Dolby Vision",dColour],
  gamut:["DCI-P3 94%",dGamut], colours:["1.07bn Colours",dColours], memc:["MEMC Motion",dMemc],
  allm:["ALLM Gaming",dAllm], audio:["60W Audio",dAudio], air:["AirPlay",dAir], voice:["Far Field Voice",dVoice]
};
const MODELS = [
{
  id:"gtv55", line:"gtv", size:'55"', color:"#3BB8F0",
  name:'55" Mini-LED  ·  Google TV',
  spec:"1400 nits · Google TV 5.0 · 120Hz · 60W",
  nits:1400, zones:[16,9],
  hi:['1400 NITS|PEAK BRIGHTNESS','DCI-P3 94%|1.07 BILLION COLOURS',
      'GOOGLE TV 5.0|FAR FIELD VOICE','60W 2.1CH|INBUILT WOOFER'],
  feats:[
    ["1400 nits peak brightness","Picture stays clear even in a bright living room — no need to draw the curtains."],
    ["DCI-P3 94% · 1.07 billion colours","Skin tones and food look real, not painted. 100% colour accuracy."],
    ["Mini LED + full array local dimming","Thousands of tiny LEDs. Dark scenes stay black instead of turning grey."],
    ["Google TV 5.0 + Far Field Voice","Speak from the sofa without touching the remote. Open app store."],
    ["60W 2.1 channel with inbuilt woofer","Real bass from the TV itself. No soundbar needed on day one."]
  ],
  more:["Dolby Vision","MEMC","ALLM","120Hz","Google Assistant","2-Way Bluetooth"],
  demo:[
    "Play a dark night scene. Point at the black — it stays black, no grey wash.",
    "Turn the showroom lights up. Picture holds because of 1400 nits.",
    "Say a command from 3 metres away — far field voice picks it up.",
    "Play a bass-heavy track. Let him hear the inbuilt woofer, no soundbar."
  ],
  pitch:"Sir, 1400 nits matlab dopahar mein bhi parda band karne ki zarurat nahi. Aur sound ke liye alag soundbar nahi lagega."
},
{
  id:"gtv65", line:"gtv", size:'65"', color:"#3BB8F0",
  name:'65" Mini-LED  ·  Google TV',
  spec:"1400 nits · Google TV 5.0 · 120Hz · 60W",
  nits:1400, zones:[18,10],
  hi:['1400 NITS|PEAK BRIGHTNESS','DCI-P3 94%|1.07 BILLION COLOURS',
      'GOOGLE TV 5.0|FAR FIELD VOICE','120Hz + ALLM|BUILT FOR GAMING'],
  feats:[
    ["1400 nits peak brightness","Bright hall, bright picture. HDR highlights actually look like light."],
    ["DCI-P3 94% · 1.07 billion colours","Wider colour range than any normal LED at this size."],
    ["Mini LED + full array local dimming","More dimming zones than a 55\" — dark detail is even more precise."],
    ["120Hz + ALLM + MEMC","Gaming and cricket with no blur and no lag. Auto low latency mode."],
    ["60W 2.1 channel with inbuilt woofer","Cinema sound in a big room without extra spend."]
  ],
  more:["Dolby Vision","Google Assistant","Far Field Voice","2-Way Bluetooth"],
  demo:[
    "Run a fast cricket or racing clip. Show MEMC — no smear on the ball.",
    "Switch to a dark movie scene and point at the shadow detail.",
    "Raise showroom lights, picture holds at 1400 nits.",
    "Connect his phone over 2-way Bluetooth and play his own song."
  ],
  pitch:"Gaming aur cricket ke liye 120Hz aur ALLM hai — ball smear nahi karegi. Yeh 65 inch pe sabse zyada dikhta hai."
},
{
  id:"gtv75", line:"gtv", size:'75"', color:"#3BB8F0",
  name:'75" Mini-LED  ·  Google TV',
  spec:"1400 nits · Google TV 5.0 · 120Hz · 60W",
  nits:1400, zones:[20,11],
  hi:['1400 NITS|PEAK BRIGHTNESS','75 INCH|FLAGSHIP SIZE',
      'DOLBY VISION|CINEMATIC HDR','60W 2.1CH|INBUILT WOOFER'],
  feats:[
    ["75\" flagship size","Our largest Mini-LED. For halls of 5 steps or more from the sofa."],
    ["1400 nits peak brightness","At this size brightness matters most — the picture never looks flat."],
    ["Dolby Vision","Deeper contrast and close-to-reality colour on supported content."],
    ["Mini LED + full array local dimming","Highest zone count in the lineup. Dark scenes stay clean at scale."],
    ["60W 2.1 channel with inbuilt woofer","Fills a large room. Dolby Audio spatial sound."]
  ],
  more:["Google TV 5.0","MEMC","ALLM","120Hz","Far Field Voice","2-Way Bluetooth"],
  demo:[
    "Ask the steps from sofa to wall. 5 steps or more means 75\" fits.",
    "Play the same Dolby Vision title against an SDR set.",
    "Dark scene first, then bright scene — show both extremes.",
    "Let him hear 60W in the open floor, not in a corner."
  ],
  pitch:"Sir, 5 kadam ya zyada ka room hai toh 75 hi sahi baithega. Chhota lene ke baad log wapas aate hain."
},
{
  id:"web55", line:"web", size:'55"', color:"#8B5CF6",
  name:'55" Mini-LED  ·  WebOS',
  spec:"1000 nits · WebOS · ThinQ AI · Magic Remote",
  nits:1000, zones:[15,8],
  hi:['1000 NITS|VIVID BRIGHTNESS','DCI-P3 94%|WIDE COLOUR GAMUT',
      'MAGIC REMOTE|POINT AND CLICK','APPLE ECOSYSTEM|AIRPLAY · HOMEKIT'],
  feats:[
    ["1000 nits peak brightness","Rich detail and deep contrast, built for HDR10 movies and games."],
    ["DCI-P3 94% wide colour gamut","Same wide gamut as the flagship line — colours stay lifelike."],
    ["Mini LED + full array local dimming","Tiny LEDs behind the panel. Blacks are black, not grey."],
    ["WebOS with ThinQ AI + Magic Remote","Point-and-click remote. AI suggests content by his own taste."],
    ["Apple ecosystem + IoT Matter","AirPlay, HomeKit, Apple TV+, Apple Music. Works with smart home."]
  ],
  more:["HDR10","Dolby Audio","MEMC","ALLM","2-Way Bluetooth"],
  demo:[
    "Hand him the Magic Remote first. Let him move the pointer.",
    "Dark scene — point at black areas staying black.",
    "If he has an iPhone, AirPlay his own photo onto the screen.",
    "Open the app store and search an app he actually uses."
  ],
  pitch:"Ye remote ek baar haath mein lijiye. Aur agar iPhone hai toh AirPlay se apni photo abhi daal ke dekhiye."
},
{
  id:"web65", line:"web", size:'65"', color:"#8B5CF6",
  name:'65" Mini-LED  ·  WebOS',
  spec:"1000 nits · WebOS · ThinQ AI · Magic Remote",
  nits:1000, zones:[17,9],
  hi:['1000 NITS|VIVID BRIGHTNESS','DCI-P3 94%|WIDE COLOUR GAMUT',
      'THINQ AI|PERSONAL SUGGESTIONS','IOT MATTER|SMART HOME READY'],
  feats:[
    ["1000 nits peak brightness","Deeper blacks and vivid colour across a bigger 65\" panel."],
    ["DCI-P3 94% wide colour gamut","Wide gamut with HDR10 — movies look the way they were shot."],
    ["Mini LED + full array local dimming","More zones than the 55\". Better shadow control at size."],
    ["ThinQ AI + Magic Remote","Personalised suggestions and a point-and-click remote."],
    ["IoT Matter + Apple ecosystem","Controls the smart home. AirPlay, HomeKit, Apple TV+, Apple Music."]
  ],
  more:["HDR10","Dolby Audio","MEMC","ALLM","2-Way Bluetooth"],
  demo:[
    "Magic Remote in his hand before any spec talk.",
    "Play an HDR10 title and point at contrast in the dark areas.",
    "Show ThinQ AI suggestions on the home row.",
    "Mention Matter if he has smart lights or plugs at home."
  ],
  pitch:"ThinQ AI aapki pasand ke hisaab se content suggest karega — har baar dhoondhna nahi padega."
}
];
/* =====================================================================
   QUESTION BANK  ·  [moduleId, question, options, answerIndex, why]
   ===================================================================== */
const Q = [
 ["m1","What makes a Mini-LED backlight different from a normal LED backlight?",
  ["The panel is thinner","Thousands of much smaller LEDs in many more dimming zones","It uses OLED pixels","It has no backlight"],1,
  "Smaller LEDs mean the backlight splits into far more independently controlled zones."],
 ["m1","What is 'blooming'?",
  ["A colour mode","Grey glow around a bright object because a whole large zone had to light up","A sound effect","A remote feature"],1,
  "With few large zones, lighting one bright object washes the surrounding dark area grey."],
 ["m1","In the display stack, what sits directly behind the LCD panel?",
  ["The remote sensor","Mini-LED backlight with full array local dimming, then the QD layer","The speaker array","The tuner board"],1,
  "Order is Mini-LED backlight with local dimming, then QD layer, then LCD panel."],
 ["m1","What does 'full array local dimming' mean?",
  ["Light comes from the edges only","Light is controlled area by area across the whole panel","The screen dims at night","The backlight never switches off"],1,
  "Full array means LEDs sit behind the whole panel and dim zone by zone, rather than edge-lit."],
 ["m2","What is the peak brightness of the Google TV Mini-LED line?",
  ["800 nits","1000 nits","1400 nits","2000 nits"],2,"The Google TV Mini-LED line reaches 1400 nits peak brightness."],
 ["m2","What is the peak brightness of the WebOS Mini-LED line?",
  ["600 nits","1000 nits","1400 nits","1800 nits"],1,"The WebOS Mini-LED line is rated at 1000 nits."],
 ["m2","What colour gamut does Mini-LED cover?",
  ["DCI-P3 72%","DCI-P3 85%","DCI-P3 94%","sRGB 100%"],2,"DCI-P3 94%, with 100% colour accuracy."],
 ["m2","What is the difference between colour gamut and colour accuracy?",
  ["They are the same","Gamut is the range of colour, accuracy is whether it is the correct colour","Gamut applies to HDR only","Accuracy is about the remote"],1,
  "Gamut is how much colour the panel can show. Accuracy is whether that colour is correct. Mini-LED delivers both."],
 ["m2","Why does a QD panel show smoother skies?",
  ["Higher refresh rate","It shows 1.07 billion shades instead of 16.7 million","More HDMI ports","A different remote"],1,
  "More shades means gradients step smoothly instead of showing visible bands."],
 ["m2","What does Dolby Vision add over standard HDR?",
  ["Louder sound","Scene-by-scene data for deeper contrast and closer-to-real colour","More apps","Faster boot"],1,
  "Dolby Vision carries dynamic, scene-by-scene metadata rather than one fixed setting for the whole film."],
 ["m2","A customer watches TV in a bright hall. Which spec matters most?",
  ["Refresh rate","Peak brightness","Bluetooth version","Remote type"],1,
  "Brightness is what stops the picture washing out in daylight. 1400 nits is the argument."],
 ["m3","Which feature helps most with fast sports and gaming?",
  ["Wide colour gamut","MEMC with 120Hz and ALLM","Inbuilt woofer","Matter support"],1,
  "MEMC smooths fast motion, 120Hz keeps it fluid, ALLM drops input lag automatically."],
 ["m3","What does ALLM do?",
  ["Raises brightness","Switches the TV to low latency game mode automatically","Adds Dolby Atmos","Extends the warranty"],1,
  "Auto Low Latency Mode switches to game mode by itself when a console connects."],
 ["m3","What problem does MEMC solve?",
  ["Weak sound","Smear and blur on fast-moving objects","Slow apps","Dim picture"],1,
  "MEMC inserts frames between frames so motion stays sharp."],
 ["m4","What is the speaker system on the Google TV Mini-LED line?",
  ["2.0 channel 20W","2.1 channel 60W with inbuilt woofer","5.1 channel 80W","Mono 10W"],1,
  "2.1 channel, 60W, with an inbuilt woofer, so real bass without a soundbar."],
 ["m4","What does the '.1' in 2.1 channel mean?",
  ["One HDMI port","A dedicated woofer for bass","One remote","Version 1"],1,
  "2.1 means a left channel, a right channel and a separate woofer."],
 ["m4","How should an SA compare sound between two TVs?",
  ["Set both to volume 20","Match actual loudness by ear, then play one bass-heavy scene","Read the wattage aloud","Use the remote mic"],1,
  "Volume numbers are not comparable across brands. Match what the ear hears."],
 ["m5","Which sizes is the Google TV Mini-LED line available in?",
  ['43 inch, 50 inch, 55 inch','50 inch, 55 inch, 65 inch','55 inch, 65 inch, 75 inch','65 inch, 75 inch, 85 inch'],2,
  "Google TV Mini-LED comes in 55, 65 and 75 inch."],
 ["m5","Which sizes does the WebOS Mini-LED line come in?",
  ['43 and 55 inch','55 and 65 inch','55, 65 and 75 inch','65 inch only'],1,"The WebOS Mini-LED line is 55 and 65 inch."],
 ["m5","What does the WebOS line offer that the Google TV line does not?",
  ["Higher brightness","Magic Remote, ThinQ AI and the Apple ecosystem","A 75 inch size","An inbuilt woofer"],1,
  "WebOS brings the Magic Remote, ThinQ AI, and Apple TV+, AirPlay, Apple Music and HomeKit."],
 ["m5","Which line carries Far Field Voice?",
  ["WebOS","Google TV 5.0","Both","Neither"],1,"Far Field Voice is on the Google TV 5.0 Mini-LED line."],
 ["m5","A customer with an iPhone walks in. Which line do you lead with?",
  ["Google TV","WebOS, for AirPlay, HomeKit and Apple TV+","Either","Neither"],1,
  "AirPlay and HomeKit are on the WebOS line. Cast his own photo in seconds."],
 ["m5","How many Mini-LED models are in the lineup?",
  ["3","4","5","6"],2,"Five: 55, 65 and 75 inch on Google TV, plus 55 and 65 inch on WebOS."]
];

/* ---------------- MODULES ---------------- */
const MODULES = [
 { id:"m1", n:1, title:"How Mini-LED Works", sub:"The backlight, the zones, the stack",
   color:"#3BB8F0", icon:"\u25C9", xp:20,
   lessons:[
    {t:"The one idea", body:"Normal LED lights the whole screen. Mini-LED lights only the part that needs light.<br><br>Every advantage \u2014 brightness, contrast, colour \u2014 comes from that single difference."},
    {t:"See it happen", demo:"dim"},
    {t:"What is behind the screen", stack:true}]},
 { id:"m2", n:2, title:"Picture Quality", sub:"Brightness, Dolby Vision, gamut, colours",
   color:"#F5B617", icon:"\u2600", xp:30,
   lessons:[{t:"Brightness", demo:"bright"},{t:"Dolby Vision vs SDR", demo:"dv"},
            {t:"Colour gamut", demo:"gamut"},{t:"1.07 billion colours", demo:"colours"}]},
 { id:"m3", n:3, title:"Motion & Gaming", sub:"MEMC, 120Hz, ALLM",
   color:"#31B85C", icon:"\u26A1", xp:20,
   lessons:[{t:"MEMC", demo:"memc"},{t:"ALLM and latency", demo:"allm"}]},
 { id:"m4", n:4, title:"Sound", sub:"60W 2.1 channel with inbuilt woofer",
   color:"#EF2B36", icon:"\u266A", xp:20,
   lessons:[{t:"60W 2.1 audio", demo:"audio"}]},
 { id:"m5", n:5, title:"Smart & Ecosystem", sub:"Google TV, WebOS, AirPlay, voice",
   color:"#8B5CF6", icon:"\u2302", xp:30,
   lessons:[{t:"Far Field Voice", demo:"voice"},{t:"AirPlay and Apple", demo:"air"},{t:"The 5 models", models:true}]}
];

/* ---------------- OBJECTION SCENARIOS ---------------- */
const SCEN = [
 { c:"Mini-LED aur normal LED mein farak kya hai? Dono LED hi toh hain.",
   o:[["Sir, Mini-LED mein zyada nits hote hain aur DCI-P3 94% gamut milta hai.",1,
       "Too technical, too early. He asked a simple question and got a spec sheet."],
      ["Dikhata hoon \u2014 yeh dark scene chalate hain. Aap aasman dekhiye.",3,
       "Right. Show, do not define. The black sky makes the point in two seconds."],
      ["Mini-LED naya technology hai Sir, premium hai.",0,
       "This says nothing. Every brand claims premium."]]},
 { c:"Brightness ka kya karna hai? Ghar mein toh andhera rehta hai.",
   o:[["Sahi hai Sir, toh brightness zaroori nahi.",0,
       "Never concede your strongest feature. And most Indian halls are bright by day."],
      ["Din mein TV nahi chalta kya Sir? Parda band karke dekhna padta hai?",3,
       "Best. A question that makes him picture his own afternoon, not an argument."],
      ["1400 nits bahut zyada hota hai Sir, aap samajh nahi rahe.",0,
       "Never tell a customer he does not understand."]]},
 { c:"Soundbar toh alag se lena hi padega na?",
   o:[["Haan Sir, sound ke liye soundbar behtar rehta hai.",0,
       "You just added cost to your own sale and gave away a real advantage."],
      ["Ismein 60W ka 2.1 system hai woofer ke saath. Ek bass wala scene chalata hoon, sun lijiye.",3,
       "Right. State it once, then prove it by ear."],
      ["Nahi Sir, bilkul zaroorat nahi, yeh best sound hai.",1,
       "Overclaiming. Let him judge instead of asserting best."]]},
 { c:"Gaming ke liye kaisa hai? Mera beta PS5 chalata hai.",
   o:[["Achha hai Sir, 120Hz hai.",1,"True but thin. You had a buying signal and let it pass."],
      ["120Hz, ALLM aur MEMC \u2014 console lagate hi TV khud game mode mein chala jaata hai. Beta ko bulake dikhaiye.",3,
       "Best. Names the three features, explains ALLM plainly, and pulls the actual user into the demo."],
      ["Gaming ke liye alag TV leni chahiye Sir.",0,"You just sent the sale out of the store."]]},
 { c:"iPhone hai mere paas. Kya isse connect hoga?",
   o:[["Haan Sir, ho jaata hai.",1,"Correct but wasted. This is the best demo moment you will get."],
      ["Phone dijiye \u2014 abhi AirPlay se aapki photo screen pe daal ke dikhata hoon.",3,
       "Best. Do it, do not describe it. Remember this is the WebOS line."],
      ["iPhone ke liye Apple TV alag se lena padega.",0,"Wrong. AirPlay is built in on the WebOS line."]]},
 { c:"Brand toh nahi suna maine. Warranty ka kya?",
   o:[["Lloyd Havells ka brand hai Sir, warranty terms yeh hain, aur nazdeeki service centre yahan hai.",3,
       "Best. One breath, no hesitation, service point named by location."],
      ["Bahut acchha brand hai Sir, tension mat lijiye.",0,"Reassurance without substance increases suspicion."],
      ["Sabhi brands ka service same hota hai.",0,"False, and it dodges a fair question."]]},
 { c:"55 aur 65 mein confuse hoon. Kaunsa loon?",
   o:[["65 le lijiye Sir, bada hi achha lagta hai.",1,"Guessing. It may be wrong for his room and come back as a complaint."],
      ["Sofa se deewar tak kitne kadam hain? 4 kadam ya zyada ho toh 65 sahi baithega.",3,
       "Best. Decide by his room, not by opinion. One step is about 2 feet."],
      ["Jo budget mein aaye woh le lijiye.",0,"You handed the decision to price and left the room out of it."]]},
 { c:"Dusre brand mein bhi Mini-LED hai, sasta bhi hai.",
   o:[["Unka Mini-LED asli nahi hota Sir.",0,"An unprovable claim that damages your credibility."],
      ["Ho sakta hai Sir. Dono pe same dark scene chalate hain, aap khud dekh lijiye.",3,
       "Best. Never argue about a rival you cannot inspect. Move to a test he can judge."],
      ["Sasta hai toh quality kam hogi.",1,"A weak generalisation the customer has heard from every salesman."]]}
];

/* ---------------- FLASHCARDS ---------------- */
const CARDS = [
 ["Google TV line \u2014 peak brightness","1400 nits"],
 ["WebOS line \u2014 peak brightness","1000 nits"],
 ["Colour gamut","DCI-P3 94% with 100% colour accuracy"],
 ["Number of colours","1.07 billion (QD display)"],
 ["Google TV line sizes","55, 65 and 75 inch"],
 ["WebOS line sizes","55 and 65 inch"],
 ["Audio system","2.1 channel, 60W, inbuilt woofer"],
 ["What ALLM does","Auto low latency \u2014 TV switches to game mode by itself"],
 ["What MEMC does","Inserts frames so fast motion stops smearing"],
 ["Refresh rate","120Hz"],
 ["Display stack order","Mini-LED backlight, then QD layer, then LCD panel"],
 ["Blooming","Grey glow around bright objects when zones are too large"],
 ["Which line has Far Field Voice","Google TV 5.0"],
 ["Which line has AirPlay and HomeKit","WebOS"],
 ["WebOS remote","Magic Remote \u2014 point and click"],
 ["WebOS AI","ThinQ AI \u2014 personalised suggestions"],
 ["HDR on Google TV line","Dolby Vision"],
 ["HDR on WebOS line","HDR10"],
 ["Smart home standard","IoT Matter (WebOS line)"],
 ["Step rule for size","1 step is about 2 feet. 4 steps means 55 to 65 inch"],
 ["Total Mini-LED models","5"],
 ["Gamut vs accuracy","Gamut is the range of colour. Accuracy is the correct colour"]
];

/* =====================================================================
   NAV STATE
   ===================================================================== */
let view="home", mod=null, les=0, model=null, mtab="feat";
let qSet=[], qi=0, qPick=-1, qScore=0, qMode="";
let sIdx=0, sPick=-1, sScore=0;
let cIdx=0, cFlip=false;
let spTime=0, spScore=0, spQ=null, spTimer=null, spOn=false;

function stopTimer(){ if(spTimer){ clearInterval(spTimer); spTimer=null; } spOn=false; }
function go(v,a){
  stopTimer(); view=v;
  if(v==="module"){ mod=MODULES.find(m=>m.id===a); les=0; }
  if(v==="model"){ model=MODELS.find(m=>m.id===a); mtab="feat"; }
  $("backBtn").classList.toggle("hide", v==="home");
  render(); window.scrollTo(0,0);
}
$("backBtn").onclick = () => {
  if(view==="lesson") return go("module", mod.id);
  if(view==="check")  return go("module", mod?mod.id:MODULES[0].id);
  if(view==="model")  return go("models");
  if(view==="module") return go("home");
  go("home");
};
function head(t,s){ $("hT").textContent=t; $("hS").textContent=s; }

function render(){
  const S=$("screen");
  const V={
   home:  ()=>{head("Mini-LED Academy","Lloyd \u00b7 New Launch"); S.innerHTML=vHome(); wHome();},
   module:()=>{head(mod.title,"Module "+mod.n+" of "+MODULES.length); S.innerHTML=vModule(); wModule();},
   lesson:()=>{head(mod.title,"Lesson "+(les+1)+" of "+mod.lessons.length); S.innerHTML=vLesson(); wLesson();},
   check: ()=>{head(qMode==="cert"?"Certification":qMode==="review"?"Review Deck":"Check yourself",
                    qMode==="module"&&mod?mod.title:""); S.innerHTML=vQuiz(); wQuiz();},
   models:()=>{head("The 5 Models","Google TV and WebOS"); S.innerHTML=vModels(); wModels();},
   model: ()=>{head(model.name,model.spec); S.innerHTML=vModel(); wModel();},
   scen:  ()=>{head("Objection Practice","Choose the best response"); S.innerHTML=vScen(); wScen();},
   flash: ()=>{head("Flashcards",(cIdx+1)+" of "+CARDS.length); S.innerHTML=vFlash(); wFlash();},
   speed: ()=>{head("Speed Round","60 seconds"); S.innerHTML=vSpeed(); wSpeed();},
   alldemos:()=>{head("All Demos",DEMOS[dKey][0]); S.innerHTML=vAllDemos(); wAllDemos();}
  };
  (V[view]||V.home)();
}

/* =====================================================================
   HOME  ·  the learning path
   ===================================================================== */
function ring(pct,size,col){
  const r=(size-8)/2, c=2*Math.PI*r;
  return '<svg width="'+size+'" height="'+size+'" viewBox="0 0 '+size+' '+size+'">' +
   '<circle cx="'+size/2+'" cy="'+size/2+'" r="'+r+'" fill="none" stroke="#1B2450" stroke-width="6"/>' +
   '<circle class="rg" cx="'+size/2+'" cy="'+size/2+'" r="'+r+'" fill="none" stroke="'+col+'" stroke-width="6" ' +
   'stroke-linecap="round" stroke-dasharray="'+c+'" stroke-dashoffset="'+(c*(1-pct/100))+'" ' +
   'transform="rotate(-90 '+size/2+' '+size/2+')"/></svg>';
}
function vHome(){
  touchStreak();
  const doneN=MODULES.filter(m=>P.done[m.id]).length;
  const pct=Math.round(doneN/MODULES.length*100);
  let feats="",dots="";
  ['MINI LED|THOUSANDS OF TINY LEDS','1400 NITS|PEAK BRIGHTNESS',
   'DCI-P3 94%|1.07 BILLION COLOURS','60W 2.1CH|INBUILT WOOFER'].forEach((t,i)=>{
    const p=t.split("|");
    feats+='<span style="animation-delay:'+(i*2.5)+'s">'+p[0]+'<i>'+p[1]+'</i></span>';
    dots +='<b style="animation-delay:'+(i*2.5)+'s"></b>';
  });
  let h=tvShell(
    zoneGrid(18,10,(x,y)=>Math.exp(-((x-.5)**2/0.10+(y-.42)**2/0.09))*.85+.05,
      v=>'rgba('+Math.round(40+140*v)+','+Math.round(90+130*v)+','+Math.round(180+70*v)+','+(0.15+0.85*v)+')') +
    '<div class="ovl">MINI LED</div><div class="ovr">NEW LAUNCH</div>' +
    '<div class="feathero">'+feats+'</div><div class="dots">'+dots+'</div>');

  h+='<div class="hero"><div class="ringwrap">'+ring(pct,84,"#3BB8F0") +
     '<div class="ringtxt"><b>'+pct+'%</b><span>done</span></div></div>' +
     '<div class="herostats">' +
       '<div class="st"><b>'+P.xp+'</b><span>XP</span></div>' +
       '<div class="st"><b>'+P.streak+'</b><span>day streak</span></div>' +
       '<div class="st"><b>'+doneN+'/'+MODULES.length+'</b><span>modules</span></div>' +
     '</div></div>';

  if(P.certified) h+='<div class="cbadge"><b>\u2713 CERTIFIED</b><span>Mini-LED Product Knowledge</span></div>';

  h+='<div class="sec">LEARNING PATH</div><div class="path">';
  MODULES.forEach((m,i)=>{
    const done=!!P.done[m.id], lock=false, best=P.best[m.id];
    h+='<div class="node'+(done?' done':'')+(lock?' lock':'')+'" data-mod="'+m.id+'">' +
      (i<MODULES.length-1?'<div class="nline"></div>':'') +
      '<div class="ndot" style="background:'+(lock?"#232C57":m.color)+(lock?';color:#5C6B99':'')+'">' +
        (done?'\u2713':(lock?'\u25CF':m.n))+'</div>' +
      '<div class="nbody"><div class="nt">'+m.title+'</div><div class="ns">'+m.sub+'</div>' +
      (best!==undefined?'<div class="nb">Best '+best+'%</div>':'') + '</div>' +
      '<div class="chev">\u203A</div></div>';
  });
  h+='</div>';

  h+='<div class="sec">PRACTICE</div><div class="tiles">' +
    tile("alldemos","\u25C9","All Demos","10 screens you can toggle") +
    tile("scen","\u25B6","Objection Practice",SCEN.length+" real situations") +
    tile("flash","\u2637","Flashcards",CARDS.length+" quick cards") +
    tile("speed","\u23F1","Speed Round",P.speedBest?("Best "+P.speedBest):"60 seconds") +
    tile("review","\u21BB","Review Deck",P.wrong.length?(P.wrong.length+" to fix"):"All clear") +
    '</div>';

  h+='<div class="sec">CERTIFICATION</div><div class="card">' +
    '<div class="big">'+(P.certified?"You are certified":"Final assessment")+'</div>' +
    '<div class="p mut">12 questions drawn from every module. 80% to pass.</div>' +
    '<button class="btn" id="toCert">'+(P.certified?"Retake":"Start assessment")+'</button></div>';
  return h;
}
function tile(id,ic,t,s){
  return '<div class="tile" data-go="'+id+'"><div class="ic">'+ic+'</div>' +
    '<div class="tt">'+t+'</div><div class="ts">'+s+'</div></div>';
}
function wHome(){
  document.querySelectorAll("[data-mod]").forEach(el=>{
    el.onclick=ev=>{ rippleAt(el,ev); setTimeout(()=>go("module",el.dataset.mod),120); };
  });
  document.querySelectorAll("[data-go]").forEach(el=>{
    el.onclick=ev=>{
      rippleAt(el,ev); const t=el.dataset.go;
      setTimeout(()=>{
        if(t==="review"){
          if(!P.wrong.length) return;
          qSet=P.wrong.slice().map(i=>({q:Q[i],id:i}));
          qi=0;qPick=-1;qScore=0;qMode="review"; go("check");
        } else if(t==="scen"){ sIdx=0;sPick=-1;sScore=0; go("scen"); }
        else if(t==="flash"){ cIdx=0;cFlip=false; go("flash"); }
        else if(t==="speed"){ spOn=false; go("speed"); }
        else if(t==="alldemos"){ dKey=Object.keys(DEMOS)[0]; go("alldemos"); }
      },120);
    };
  });
  const c=$("toCert");
  if(c && !c.disabled) c.onclick=ev=>{
    rippleAt(c,ev);
    qSet=shuffle(Q.map((q,i)=>({q,id:i}))).slice(0,12);
    qi=0;qPick=-1;qScore=0;qMode="cert"; go("check");
  };
}

/* =====================================================================
   ALL DEMOS  (flat browser)
   ===================================================================== */
let dKey = "dim";
function vAllDemos(){
  const keys=Object.keys(DEMOS), d=DEMOS[dKey][1]();
  let h='<div class="chips" id="dchips">'+keys.map(k=>
    '<button class="chip2'+(k===dKey?" on":"")+'" data-dk="'+k+'">'+DEMOS[k][0]+'</button>'
  ).join("")+'</div>';
  h+='<div class="card"><h3>'+DEMOS[dKey][0].toUpperCase()+'</h3>' +
     tvShell('<div id="dscr">'+d.scr+'</div>',{cap:d.cap});
  if(d.range){
    const v=ds(d.range.key,d.range.max);
    h+='<div class="slab"><span>Drag to change</span><b id="rlab">'+v+d.range.label+'</b></div>' +
      '<input type="range" id="drange" min="'+d.range.min+'" max="'+d.range.max+'" step="'+d.range.step+'" value="'+v+'">';
  }
  h+='<div class="seg" id="dseg">'+d.seg.map(s=>
    '<button data-k="'+s[0]+'" data-v="'+(s[1]?1:0)+'" class="'+(ds(s[0],true)===s[1]?"on":"")+'">'+s[2]+'</button>'
  ).join("")+'</div></div>';
  h+='<div class="card"><h3>WHAT TO SAY WHILE THEY WATCH</h3>';
  d.tp.forEach(t=>h+='<div class="tp"><div class="tpd" style="background:'+t[1]+'"></div><div class="tpt">'+t[0]+'</div></div>');
  h+='</div>';
  if(d.note) h+='<div class="card mut" style="font-size:12.5px">'+d.note+'</div>';
  const i=keys.indexOf(dKey);
  h+='<div class="seg" style="margin-top:4px">' +
    '<button id="dprev">\u2039 Previous</button><button id="dnext" class="on">Next \u203A</button></div>';
  return h;
}
function wAllDemos(){
  const keys=Object.keys(DEMOS);
  document.querySelectorAll("[data-dk]").forEach(b=>{
    b.onclick=ev=>{ rippleAt(b,ev); dKey=b.dataset.dk;
      head("All Demos",DEMOS[dKey][0]);
      $("screen").innerHTML=vAllDemos(); wAllDemos(); window.scrollTo({top:0,behavior:"smooth"}); };
  });
  document.querySelectorAll("#dseg button").forEach(b=>{
    b.onclick=ev=>{ rippleAt(b,ev); buzz(9); dState[b.dataset.k]=b.dataset.v==="1";
      $("screen").innerHTML=vAllDemos(); wAllDemos(); };
  });
  const r=$("drange");
  if(r) r.oninput=()=>{ const d=DEMOS[dKey][1]();
    dState[d.range.key]=+r.value; $("rlab").textContent=r.value+d.range.label;
    $("dscr").innerHTML=DEMOS[dKey][1]().scr; };
  const p=$("dprev"), n=$("dnext");
  const move=s=>{ const i=keys.indexOf(dKey); dKey=keys[(i+s+keys.length)%keys.length];
    head("All Demos",DEMOS[dKey][0]);
    $("screen").innerHTML=vAllDemos(); wAllDemos(); window.scrollTo({top:0,behavior:"smooth"}); };
  if(p) p.onclick=ev=>{ rippleAt(p,ev); move(-1); };
  if(n) n.onclick=ev=>{ rippleAt(n,ev); move(1); };
}

/* =====================================================================
   MODULE
   ===================================================================== */
function vModule(){
  const m=mod, done=!!P.done[m.id];
  let h='<div class="mhead2" style="background:linear-gradient(135deg,'+m.color+'26,#1B2450)">' +
    '<div class="mic2" style="background:'+m.color+'">'+m.icon+'</div>' +
    '<div><div class="mt">'+m.title+'</div><div class="msb">'+m.sub+'</div></div></div>';
  h+='<div class="sec">LESSONS</div>';
  m.lessons.forEach((l,i)=>{
    h+='<div class="lrow" data-les="'+i+'"><div class="ln" style="background:'+m.color+'">'+(i+1)+'</div>' +
      '<div class="lt">'+l.t+'</div><div class="chev">\u203A</div></div>';
  });
  const n=Q.filter(q=>q[0]===m.id).length;
  h+='<div class="card" style="margin-top:14px"><h3>CHECK YOURSELF</h3>' +
    '<div class="p">'+n+' questions on this module. Answer them and the module is marked complete.</div>' +
    (done?'<div class="okline">\u2713 Completed \u00b7 best score '+P.best[m.id]+'%</div>':'') +
    '<button class="btn" id="startCheck">'+(done?"Practise again":"Start check")+'</button></div>';
  return h;
}
function wModule(){
  document.querySelectorAll("[data-les]").forEach(el=>{
    el.onclick=ev=>{ rippleAt(el,ev); les=+el.dataset.les; setTimeout(()=>go("lesson"),110); };
  });
  const b=$("startCheck");
  if(b) b.onclick=ev=>{
    rippleAt(b,ev);
    qSet=shuffle(Q.map((q,i)=>({q,id:i})).filter(x=>x.q[0]===mod.id));
    qi=0;qPick=-1;qScore=0;qMode="module"; go("check");
  };
}

/* =====================================================================
   LESSON
   ===================================================================== */
function lay(t,s,c,bg){
  return '<div class="ly" style="background:'+bg+';border-color:'+c+'55">' +
    '<b style="color:'+c+'">'+t+'</b><span>'+s+'</span></div>';
}
function vLesson(){
  const l=mod.lessons[les];
  let h='<div class="lprog">Lesson '+(les+1)+' of '+mod.lessons.length+'</div>';
  if(l.body) h+='<div class="card"><div class="big">'+l.t+'</div><div class="p">'+l.body+'</div></div>';
  if(l.stack){
    h+='<div class="card"><h3>WHAT IS BEHIND THE SCREEN</h3><div class="stack">' +
      lay("Mini-LED backlight","Thousands of tiny LEDs with full array local dimming","#3BB8F0","#0E2B44") +
      lay("QD layer (QD-DP)","Quantum dots create 1.07 billion colours, DCI-P3 94%","#F5B617","#332708") +
      lay("LCD panel","Forms the picture from the light behind it","#8B5CF6","#241A44") +
      lay("Picture engine","Dolby Vision / HDR10, MEMC, 100% colour accuracy","#31B85C","#0E2E1C") +
      '</div></div>';
  }
  if(l.demo){
    const d=DEMOS[l.demo][1]();
    h+='<div class="card"><h3>'+DEMOS[l.demo][0].toUpperCase()+'</h3>' +
      tvShell('<div id="dscr">'+d.scr+'</div>',{cap:d.cap});
    if(d.range){
      const v=ds(d.range.key,d.range.max);
      h+='<div class="slab"><span>Drag to change</span><b id="rlab">'+v+d.range.label+'</b></div>' +
        '<input type="range" id="drange" min="'+d.range.min+'" max="'+d.range.max+'" step="'+d.range.step+'" value="'+v+'">';
    }
    h+='<div class="seg" id="dseg">'+d.seg.map(s=>
      '<button data-k="'+s[0]+'" data-v="'+(s[1]?1:0)+'" class="'+(ds(s[0],true)===s[1]?"on":"")+'">'+s[2]+'</button>'
    ).join("")+'</div></div>';
    h+='<div class="card"><h3>WHAT TO SAY WHILE THEY WATCH</h3>';
    d.tp.forEach(t=>h+='<div class="tp"><div class="tpd" style="background:'+t[1]+'"></div><div class="tpt">'+t[0]+'</div></div>');
    h+='</div>';
    if(d.note) h+='<div class="card mut" style="font-size:12.5px">'+d.note+'</div>';
    h+='<input type="hidden" id="demoKey" value="'+l.demo+'">';
  }
  if(l.models){
    h+='<div class="card"><h3>THE LINEUP</h3><div class="big">5 models across 2 operating systems</div>' +
      '<div class="p mut">Google TV: 55, 65 and 75 inch at 1400 nits.<br>WebOS: 55 and 65 inch at 1000 nits.</div>' +
      '<button class="btn" id="toModels">Open the model cards</button></div>';
  }
  h+='<div class="seg" style="margin-top:6px">' +
    '<button id="lprev"'+(les===0?' disabled':'')+'>\u2039 Previous</button>' +
    '<button id="lnext" class="on">'+(les===mod.lessons.length-1?"Finish lessons":"Next \u203A")+'</button></div>';
  return h;
}
function wLesson(){
  const dk=$("demoKey")?$("demoKey").value:null;
  document.querySelectorAll("#dseg button").forEach(b=>{
    b.onclick=ev=>{ rippleAt(b,ev); buzz(9);
      dState[b.dataset.k]=b.dataset.v==="1";
      $("screen").innerHTML=vLesson(); wLesson(); };
  });
  const r=$("drange");
  if(r&&dk) r.oninput=()=>{
    const d=DEMOS[dk][1]();
    dState[d.range.key]=+r.value;
    $("rlab").textContent=r.value+d.range.label;
    $("dscr").innerHTML=DEMOS[dk][1]().scr;
  };
  const tm=$("toModels"); if(tm) tm.onclick=ev=>{ rippleAt(tm,ev); go("models"); };
  const p=$("lprev"), n=$("lnext");
  if(p&&!p.disabled) p.onclick=ev=>{ rippleAt(p,ev); les--; $("screen").innerHTML=vLesson(); wLesson(); window.scrollTo(0,0); };
  if(n) n.onclick=ev=>{
    rippleAt(n,ev);
    if(les<mod.lessons.length-1){ les++; head(mod.title,"Lesson "+(les+1)+" of "+mod.lessons.length);
      $("screen").innerHTML=vLesson(); wLesson(); window.scrollTo(0,0); }
    else go("module",mod.id);
  };
}

/* =====================================================================
   QUIZ ENGINE
   ===================================================================== */
function vQuiz(){
  if(qi>=qSet.length){
    const pct=qSet.length?Math.round(qScore/qSet.length*100):0;
    let h='';
    if(qMode==="module"){
      const first=!P.done[mod.id];
      P.done[mod.id]=true;
      P.best[mod.id]=Math.max(P.best[mod.id]||0,pct);
      if(first) addXP(mod.xp);
      save();
      h='<div class="card res"><div class="score">'+qScore+'/'+qSet.length+'</div>' +
        '<div class="resm">'+(pct>=80?"Module complete.":"Module complete \u2014 worth another pass.")+'</div>' +
        '<div class="mut">'+pct+'% correct'+(first?" \u00b7 +"+mod.xp+" XP":"")+'</div>' +
        (P.wrong.length?'<div class="mut" style="margin-top:8px">'+P.wrong.length+' in your review deck.</div>':'') +
        '<button class="btn" id="qhome">Back to path</button></div>';
    } else if(qMode==="cert"){
      const pass=pct>=80;
      if(pass&&!P.certified){ P.certified=true; addXP(100); }
      save();
      h='<div class="card res">'+(pass?'<div class="seal">\u2713</div>':'') +
        '<div class="score">'+qScore+'/'+qSet.length+'</div>' +
        '<div class="resm">'+(pass?"Certified.":"Not yet \u2014 80% needed.")+'</div>' +
        '<div class="mut">'+pct+'% correct'+(pass?" \u00b7 +100 XP":"")+'</div>' +
        (pass?'<div class="certname">Mini-LED Product Knowledge<br><span>Lloyd \u00b7 East Zone Training</span></div>':'') +
        (pass?'':'<button class="btn" id="qretry">Try the assessment again</button>') +
        '<button class="btn'+(pass?'':' ghost')+'" id="qhome">Back to path</button></div>';
    } else {
      h='<div class="card res"><div class="score">'+qScore+'/'+qSet.length+'</div>' +
        '<div class="resm">'+(P.wrong.length?P.wrong.length+" still in the deck.":"Review deck is clear.")+'</div>' +
        '<button class="btn" id="qhome">Back to path</button></div>';
    }
    return h;
  }
  const it=qSet[qi], q=it.q;
  let h='<div class="prog"><i style="width:'+(qi/qSet.length*100)+'%"></i></div>' +
    '<div class="card"><div class="qn">QUESTION '+(qi+1)+' OF '+qSet.length+'</div>' +
    '<div class="qq">'+esc(q[1])+'</div>';
  q[2].forEach((o,i)=>{
    let c=""; if(qPick>-1) c=(i===q[3])?" ok":(i===qPick?" no":"");
    h+='<button class="opt'+c+'" data-o="'+i+'"'+(qPick>-1?" disabled":"")+'>'+esc(o)+'</button>';
  });
  if(qPick>-1){
    h+='<div class="exp"><b style="color:'+(qPick===q[3]?"#31B85C":"#EF2B36")+'">' +
      (qPick===q[3]?"Correct":"Not quite")+'</b> \u2014 '+esc(q[4])+'</div>' +
      '<button class="btn" id="qnext">'+(qi===qSet.length-1?"See result":"Next")+'</button>';
  }
  return h+'</div>';
}
function wQuiz(){
  document.querySelectorAll("[data-o]").forEach(b=>{
    b.onclick=ev=>{
      if(qPick>-1) return;
      rippleAt(b,ev); qPick=+b.dataset.o;
      const it=qSet[qi];
      if(qPick===it.q[3]){ qScore++; buzz(14); clearWrong(it.id); }
      else { buzz([8,50,8]); markWrong(it.id); }
      $("screen").innerHTML=vQuiz(); wQuiz();
    };
  });
  const n=$("qnext");
  if(n) n.onclick=ev=>{ rippleAt(n,ev); qi++; qPick=-1;
    $("screen").innerHTML=vQuiz(); wQuiz(); window.scrollTo({top:0,behavior:"smooth"}); };
  const rt=$("qretry");
  if(rt) rt.onclick=ev=>{ rippleAt(rt,ev);
    qSet=shuffle(Q.map((q,i)=>({q,id:i}))).slice(0,12);
    qi=0;qPick=-1;qScore=0;qMode="cert";
    $("screen").innerHTML=vQuiz(); wQuiz(); window.scrollTo(0,0); };
  const hb=$("qhome"); if(hb) hb.onclick=ev=>{ rippleAt(hb,ev); go("home"); };
}

/* =====================================================================
   OBJECTION SCENARIOS
   ===================================================================== */
function vScen(){
  if(sIdx>=SCEN.length){
    const max=SCEN.length*3, pct=Math.round(sScore/max*100);
    return '<div class="card res"><div class="score">'+sScore+'/'+max+'</div>' +
      '<div class="resm">'+(pct>=80?"Strong handling.":pct>=50?"Reasonable \u2014 sharpen the weak ones.":"Work through these again.")+'</div>' +
      '<div class="mut">'+pct+'% \u00b7 best answers score 3</div>' +
      '<button class="btn" id="sagain">Try again</button>' +
      '<button class="btn ghost" id="shome">Back to path</button></div>';
  }
  const s=SCEN[sIdx], best=Math.max.apply(null,s.o.map(x=>x[1]));
  let h='<div class="prog"><i style="width:'+(sIdx/SCEN.length*100)+'%"></i></div>' +
    '<div class="card"><div class="qn">SITUATION '+(sIdx+1)+' OF '+SCEN.length+'</div>' +
    '<div class="cust"><div class="cav">\u25CF</div><div class="cbub">\u201C'+esc(s.c)+'\u201D</div></div>';
  s.o.forEach((o,i)=>{
    let c=""; if(sPick>-1) c=(o[1]===best)?" ok":(i===sPick?" no":"");
    h+='<button class="opt'+c+'" data-s="'+i+'"'+(sPick>-1?" disabled":"")+'>'+esc(o[0])+'</button>';
  });
  if(sPick>-1){
    const o=s.o[sPick];
    h+='<div class="exp"><b style="color:'+(o[1]===best?"#31B85C":o[1]>0?"#F5B617":"#EF2B36")+'">+' +
      o[1]+' \u2014 '+(o[1]===best?"Best response":o[1]>0?"Workable, not best":"Avoid this")+'</b><br>'+esc(o[2])+'</div>' +
      '<button class="btn" id="snext">'+(sIdx===SCEN.length-1?"See result":"Next situation")+'</button>';
  }
  return h+'</div>';
}
function wScen(){
  document.querySelectorAll("[data-s]").forEach(b=>{
    b.onclick=ev=>{
      if(sPick>-1) return;
      rippleAt(b,ev); sPick=+b.dataset.s;
      const s=SCEN[sIdx], best=Math.max.apply(null,s.o.map(x=>x[1]));
      sScore+=s.o[sPick][1]; buzz(s.o[sPick][1]===best?14:[8,50,8]);
      $("screen").innerHTML=vScen(); wScen();
    };
  });
  const n=$("snext");
  if(n) n.onclick=ev=>{ rippleAt(n,ev); sIdx++; sPick=-1;
    $("screen").innerHTML=vScen(); wScen(); window.scrollTo({top:0,behavior:"smooth"}); };
  const a=$("sagain"); if(a) a.onclick=ev=>{ rippleAt(a,ev); sIdx=0;sPick=-1;sScore=0; $("screen").innerHTML=vScen(); wScen(); };
  const hb=$("shome"); if(hb) hb.onclick=ev=>{ rippleAt(hb,ev); addXP(15); go("home"); };
}

/* =====================================================================
   FLASHCARDS
   ===================================================================== */
function vFlash(){
  const c=CARDS[cIdx];
  return '<div class="prog"><i style="width:'+((cIdx+1)/CARDS.length*100)+'%"></i></div>' +
    '<div class="flip'+(cFlip?" f":"")+'" id="flip"><div class="finner">' +
      '<div class="fface ffront"><div class="fq">'+esc(c[0])+'</div><div class="fhint">tap to reveal</div></div>' +
      '<div class="fface fback"><div class="fa">'+esc(c[1])+'</div></div>' +
    '</div></div>' +
    '<div class="seg" style="margin-top:14px">' +
    '<button id="fprev">\u2039 Back</button><button id="fnext" class="on">Next \u203A</button></div>' +
    '<div class="card mut" style="margin-top:12px;font-size:12.5px">' +
    'Two minutes before the shift opens. Say the answer out loud, then tap.</div>';
}
function wFlash(){
  const f=$("flip");
  if(f) f.onclick=ev=>{ rippleAt(f,ev); cFlip=!cFlip; buzz(8); $("screen").innerHTML=vFlash(); wFlash(); };
  const p=$("fprev"), n=$("fnext");
  if(p) p.onclick=ev=>{ rippleAt(p,ev); cIdx=(cIdx-1+CARDS.length)%CARDS.length; cFlip=false;
    head("Flashcards",(cIdx+1)+" of "+CARDS.length); $("screen").innerHTML=vFlash(); wFlash(); };
  if(n) n.onclick=ev=>{ rippleAt(n,ev); cIdx=(cIdx+1)%CARDS.length; cFlip=false;
    head("Flashcards",(cIdx+1)+" of "+CARDS.length); $("screen").innerHTML=vFlash(); wFlash(); };
}

/* =====================================================================
   SPEED ROUND
   ===================================================================== */
function nextSpeed(){ spQ=shuffle(Q.map((q,i)=>({q,id:i})))[0]; }
function vSpeed(){
  if(!spOn){
    return '<div class="card res"><div class="big">Speed Round</div>' +
      '<div class="p mut">60 seconds. As many as you can. Wrong answers go to your review deck.</div>' +
      (P.speedBest?'<div class="mut" style="margin-top:8px">Your best: <b style="color:#F5B617">'+P.speedBest+'</b></div>':'') +
      (spScore?'<div class="score" style="margin-top:14px">'+spScore+'</div><div class="mut">last run</div>':'') +
      '<button class="btn" id="spstart">'+(spScore?"Go again":"Start")+'</button>' +
      '<button class="btn ghost" id="sphome">Back to path</button></div>';
  }
  const q=spQ.q;
  let h='<div class="timer"><div class="tbar"><i style="width:'+(spTime/60*100)+'%"></i></div>' +
    '<div class="tlab"><span>'+spTime+'s</span><span>Score '+spScore+'</span></div></div>' +
    '<div class="card"><div class="qq">'+esc(q[1])+'</div>';
  q[2].forEach((o,i)=>h+='<button class="opt" data-sp="'+i+'">'+esc(o)+'</button>');
  return h+'</div>';
}
function wSpeed(){
  const s=$("spstart");
  if(s) s.onclick=ev=>{
    rippleAt(s,ev); spOn=true; spScore=0; spTime=60; nextSpeed();
    $("screen").innerHTML=vSpeed(); wSpeed();
    spTimer=setInterval(()=>{
      spTime--;
      if(spTime<=0){
        stopTimer();
        if(spScore>P.speedBest) P.speedBest=spScore;
        addXP(spScore*2); save();
        $("screen").innerHTML=vSpeed(); wSpeed(); return;
      }
      const t=document.querySelector(".tbar i"), l=document.querySelector(".tlab span");
      if(t) t.style.width=(spTime/60*100)+"%";
      if(l) l.textContent=spTime+"s";
    },1000);
  };
  const hb=$("sphome"); if(hb) hb.onclick=ev=>{ rippleAt(hb,ev); go("home"); };
  document.querySelectorAll("[data-sp]").forEach(b=>{
    b.onclick=ev=>{
      const i=+b.dataset.sp;
      if(i===spQ.q[3]){ spScore++; buzz(12); clearWrong(spQ.id); b.classList.add("ok"); }
      else { buzz([8,40,8]); markWrong(spQ.id); b.classList.add("no"); }
      setTimeout(()=>{ nextSpeed(); $("screen").innerHTML=vSpeed(); wSpeed(); },220);
    };
  });
}

/* =====================================================================
   MODELS
   ===================================================================== */
function miniTV(){
  return '<div class="mtv"><div class="bezel"><div class="scr">' +
    zoneGrid(8,5,(x,y)=>Math.exp(-((x-.5)**2/0.12+(y-.45)**2/0.10))*.9+.05,
      v=>'rgba('+Math.round(50+150*v)+','+Math.round(110+120*v)+','+Math.round(200+55*v)+','+(0.15+0.85*v)+')') +
    '<div class="vig"></div></div></div><div class="neck"></div><div class="base"></div></div>';
}
function vModels(){
  let h='<div class="card"><h3>THE LINEUP</h3><div class="big">5 Mini-LED models, 2 operating systems</div></div>';
  h+='<div class="sec">GOOGLE TV 5.0 \u00b7 1400 NITS</div>';
  MODELS.filter(m=>m.line==="gtv").forEach(m=>h+=mrow(m));
  h+='<div class="sec">WEBOS \u00b7 1000 NITS \u00b7 MAGIC REMOTE</div>';
  MODELS.filter(m=>m.line==="web").forEach(m=>h+=mrow(m));
  h+='<div class="card mut" style="font-size:12.5px">Model codes were not in the launch deck. Add SKU numbers when the price list circulates.</div>';
  return h;
}
function mrow(m){
  return '<div class="mrow" data-m="'+m.id+'">'+miniTV()+'<div style="min-width:0">' +
    '<div class="mn"><span class="chip" style="background:'+m.color+'">'+m.size+'</span>' +
    (m.line==="gtv"?"Google TV":"WebOS")+'</div><div class="ms">'+m.spec+'</div></div>' +
    '<div class="chev">\u203A</div></div>';
}
function wModels(){
  document.querySelectorAll("[data-m]").forEach(el=>{
    el.onclick=ev=>{ rippleAt(el,ev); setTimeout(()=>go("model",el.dataset.m),120); };
  });
}
function vModel(){
  const m=model;
  let feats="",dots="";
  m.hi.forEach((t,i)=>{
    const p=t.split("|");
    feats+='<span style="animation-delay:'+(i*2.5)+'s">'+p[0]+(p[1]?'<i>'+p[1]+'</i>':'')+'</span>';
    dots +='<b style="animation-delay:'+(i*2.5)+'s"></b>';
  });
  const f=m.nits/1400;
  let h=tvShell(
    zoneGrid(m.zones[0],m.zones[1],(x,y)=>Math.min(1,Math.exp(-((x-.5)**2/0.12+(y-.45)**2/0.10))*(0.55+0.45*f)+.04),
      v=>'rgba('+Math.round(45+150*v)+','+Math.round(100+125*v)+','+Math.round(190+65*v)+','+(0.12+0.88*v).toFixed(3)+')') +
    '<div class="ovl">'+(m.line==="gtv"?"GOOGLE TV 5.0":"WEBOS")+'</div>' +
    '<div class="ovr">'+m.nits+' NITS</div>' +
    '<div class="feathero">'+feats+'</div><div class="dots">'+dots+'</div>',
    {cap:m.size+' \u00b7 '+m.nits+' nits \u00b7 zones shown for illustration'});
  h+='<div class="seg" id="mtabs">' +
    [["feat","Features"],["demo","Demo"],["pitch","Pitch"],["spec","All"]].map(t=>
      '<button data-mt="'+t[0]+'" class="'+(mtab===t[0]?"on":"")+'">'+t[1]+'</button>').join("")+'</div>';
  if(mtab==="feat"){
    h+='<div class="card" style="margin-top:12px"><h3>5 KEY FEATURES AND WHAT THEY MEAN</h3>';
    m.feats.forEach((f2,i)=>h+='<div class="fr"><div class="fn" style="background:'+m.color+'">'+(i+1)+'</div>' +
      '<div><div class="fh">'+esc(f2[0])+'</div><div class="fb">'+esc(f2[1])+'</div></div></div>');
    h+='</div>';
  }
  if(mtab==="demo"){
    h+='<div class="card" style="margin-top:12px"><h3>DEMO \u2014 IN THIS ORDER</h3>';
    m.demo.forEach((d,i)=>h+='<div class="fr"><div class="fn" style="background:'+m.color+'">'+(i+1)+'</div>' +
      '<div><div class="fb" style="color:var(--txt);font-size:14px">'+esc(d)+'</div></div></div>');
    h+='</div>';
  }
  if(mtab==="pitch"){
    h+='<div class="card" style="margin-top:12px"><h3>SAY THIS</h3>' +
      '<div class="big" style="font-style:italic;font-size:17px">\u201C'+esc(m.pitch)+'\u201D</div></div>';
  }
  if(mtab==="spec"){
    h+='<div class="card" style="margin-top:12px"><h3>EVERYTHING ON THIS MODEL</h3>';
    m.feats.forEach(f2=>h+='<div class="fr"><div class="fn" style="background:'+m.color+'">\u2022</div>' +
      '<div><div class="fh">'+esc(f2[0])+'</div></div></div>');
    m.more.forEach(x=>h+='<div class="fr"><div class="fn" style="background:#3A4674;color:#fff">\u2022</div>' +
      '<div><div class="fh">'+esc(x)+'</div></div></div>');
    h+='</div>';
  }
  return h;
}
function wModel(){
  document.querySelectorAll("[data-mt]").forEach(b=>{
    b.onclick=ev=>{ rippleAt(b,ev); mtab=b.dataset.mt; $("screen").innerHTML=vModel(); wModel(); };
  });
}

/* ---------------- BOOT ---------------- */
render();
if("serviceWorker" in navigator){
  addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
}
